export const fetchPosts = "FETCH_POSTS";
export const fetchOnePOst = "FETCH_ONE_POST";
export const addPost = "ADD_POST";
export const editPost = "EDIT_POST";
export const deletePost = "DELETE_POST";
export const likePost = "LIKE_POST";
export const unlinkePost = "UNLIKE_POST";