let posts = [
    {
        "id": "1",
        "title": "Some title",
        "category":"some category",
        "content": "some content"
    },
    {
        "id": "2",
        "title": "Some title 2 ",
        "category":"some category",
        "content": "some content"
    },
    {
        "id": "3",
        "title": "Some title 3 ",
        "category":"some category",
        "content": "some content"
    }
];

module.exports = posts;