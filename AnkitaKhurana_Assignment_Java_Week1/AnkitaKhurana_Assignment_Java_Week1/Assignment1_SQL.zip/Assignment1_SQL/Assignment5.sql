--Write a Procedure supplying name information from the Person.Person table and accepting a filter for the first name. Alter the above Store Procedure to supply Default Values if user does not enter any value.( Use AdventureWorks)

IF OBJECT_ID ( 'filterName', 'P' ) IS NOT NULL   
    DROP PROCEDURE filterName;  
GO 

CREATE PROCEDURE filterName ( @MyName  Nvarchar(20) = 'A%')
AS
BEGIN	
	SELECT *
    FROM Person.Person
	WHERE
		FirstName LIKE @MyName
	RETURN 0
END