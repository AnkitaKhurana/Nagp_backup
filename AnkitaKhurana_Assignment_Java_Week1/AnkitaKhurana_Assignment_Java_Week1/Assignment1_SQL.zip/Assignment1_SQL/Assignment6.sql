--Write a trigger for the Product table to ensure the list price can never be raised more than 15 Percent in a single change. Modify the above trigger to execute its check code only if the ListPrice column is   updated (Use AdventureWorks Database).

use AdventureWorks;

IF OBJECT_ID ('UpdateListPriceTrigger', 'TR') IS NOT NULL  
   DROP TRIGGER a;  
GO 

CREATE TRIGGER UpdateListPriceTrigger
on Production.Product
FOR UPDATE
AS
IF EXISTS
	(SELECT 'True'
	FROM Inserted i
	JOIN Deleted d
		ON i.ProductID = d.ProductID
		WHERE ((15*(d.ListPrice)/100) < i.ListPrice - d.ListPrice)
	)
	BEGIN
		RAISERROR('Cannot Update more than 15%',1,1)
		ROLLBACK TRAN
	END



