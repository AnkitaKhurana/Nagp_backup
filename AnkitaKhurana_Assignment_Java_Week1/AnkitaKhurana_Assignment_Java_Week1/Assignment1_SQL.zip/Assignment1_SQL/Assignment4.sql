--Display the Name and Color of the Product with the maximum weight. (Schema(s) involved: Production)

IF OBJECT_ID (N'ConvertCurrencyTo', N'IF') IS NOT NULL  
    DROP FUNCTION ConvertCurrencyTo;  
GO 

CREATE FUNCTION ConvertCurrencyTo (@SalesOrderID int , @currencyCode varchar (3) , @date Date)
RETURNS TABLE  
AS  
RETURN   
(  
    SELECT 
		ProductID, 
		FromCurrencyCode, 
		ToCurrencyCode, 
		OrderQty , 
		CurrencyRateDate , 
		UnitPrice,
		UnitPrice*EndOfDayRate AS 'Unit Price Converted' 	
		
	FROM 
		Sales.CurrencyRate, 
		Sales.SalesOrderHeader, 
		Sales.SalesOrderDetail 
	WHERE 
		Sales.SalesOrderHeader.SalesOrderID= Sales.SalesOrderDetail.SalesOrderID	
		AND 
		CurrencyRateDate=@date
		AND
		ToCurrencyCode=@currencyCode	
		AND
		SalesOrderHeader.SalesOrderID= @SalesOrderID
);  