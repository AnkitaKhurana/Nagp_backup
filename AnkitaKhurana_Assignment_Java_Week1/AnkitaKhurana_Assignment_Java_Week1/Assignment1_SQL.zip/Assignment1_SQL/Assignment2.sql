--Write separate queries using a join, a subquery, a CTE, and then an EXISTS to list all AdventureWorks customers who have not placed an order.

--Using Subquery
Use AdventureWorks;

SELECT 
	CustomerID 
FROM 
	Sales.Customer 
Where 
	CustomerID 
	NOT IN
	(
	SELECT 
		SS.CustomerID 
	FROM 
		Sales.SalesOrderHeader 
	AS 
		SS
	)

--Using Left Join

SELECT     
	Sales.Customer.CustomerID
FROM       
	Sales.Customer
	LEFT JOIN  
	Sales.SalesOrderHeader 
ON 
	Sales.Customer.CustomerID =  Sales.SalesOrderHeader.CustomerID
WHERE      
	Sales.SalesOrderHeader.CustomerID 
	IS NULL;


--Using Exists

SELECT 
	CustomerID 
FROM 
	Sales.Customer 
Where 
	NOT EXISTS 
	(
	SELECT CustomerID
	FROM 
		Sales.SalesOrderHeader 
	WHERE 
		Sales.Customer.CustomerID = Sales.SalesOrderHeader.CustomerID
	);

--Using CTE (Common Table Expression)


WITH 
	AllCustomers (CustomerID)
AS 
	(
	SELECT 
		CustomerID 
	FROM 
	Sales.Customer
	)


SELECT 
	CustomerID 
FROM 
	AllCustomers 
Where 
	CustomerID 
	NOT IN
	(
	SELECT 
		SS.CustomerID 
	FROM 
		Sales.SalesOrderHeader 
	AS 
		SS
	)



--Using Except

SELECT 
	CustomerID 
FROM 
	Sales.Customer
EXCEPT
	SELECT 
		CustomerID 
	FROM 
		Sales.SalesOrderHeader