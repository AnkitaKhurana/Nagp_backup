--The exercise requires SQL Server AdventureWorks OLTP database which can be found at Codeplex. Download and attach a copy of the database to your server instance. Take some time to appreciate the entire schema of the database, and functions and stored procedures (refer AdventureWorks 2008 OLTP Schema.pdf). Using the AdventureWorks database, perform the following queries.
--1.	Display the number of records in the [SalesPerson] table. (Schema(s) involved: Sales)
--2.	Select both the FirstName and LastName of records from the Person table where the FirstName begins with the letter �B�. (Schema(s) involved: Person)
--3.	Select a list of FirstName and LastName for employees where Title is one of Design Engineer, Tool Designer or Marketing Assistant. (Schema(s) involved: HumanResources, Person)
--4.	Display the Name and Color of the Product with the maximum weight. (Schema(s) involved: Production)
--5.	Display Description and MaxQty fields from the SpecialOffer table. Some of the MaxQty values are NULL, in this case display the value 0.00 instead. (Schema(s) involved: Sales)
--6.	Display the overall Average of the [CurrencyRate].[AverageRate] values for the exchange rate �USD� to �GBP� for the year 2005 i.e. FromCurrencyCode = �USD� and ToCurrencyCode = �GBP�. Note: The field [CurrencyRate].[AverageRate] is defined as 'Average exchange rate for the day.' (Schema(s) involved: Sales)
--7.	Display the FirstName and LastName of records from the Person table where FirstName contains the letters �ss�. Display an additional column with sequential numbers for each row returned beginning at integer 1. (Schema(s) involved: Person)
--8.	Sales people receive various commission rates that belong to 1 of 4 bands. (Schema(s) involved: Sales)
--Display the [SalesPersonID] with an additional column entitled �Commission Band� indicating the appropriate band as above.
--9.	Display the managerial hierarchy from Ruth Ellerbrock (person type � EM) up to CEO Ken Sanchez. Hint: use [uspGetEmployeeManagers] (Schema(s) involved: [Person], [HumanResources]) 
--10.	Display the ProductId of the product with the largest stock level. Hint: Use the Scalar-valued function [dbo]. [UfnGetStock]. (Schema(s) involved: Production)



use AdventureWorks;

--Question 1.
SELECT 
	Count(*) 
FROM 
	Sales.SalesPerson;


--Question 2

SELECT 
	FirstName, 
	LastName 
FROM
	 Person.Person 
WHERE
	 FirstName LIKE 'B%';  

--Question 3

SELECT 
	P.FirstName, 
	P.LastName, 
	E.JobTitle 
FROM 
	Person.Person P, 
	HumanResources.Employee  E
WHERE 
	JobTitle 
	IN 
	('Design Engineer','Marketing Assistant','Tool Designer')

--Question 4

SELECT 
	Name, 
	Color 
FROM 
	Production.Product
WHERE 
	Weight = 
		(SELECT 
			MAX(Weight) 
		 FROM 
			Production.Product);

--Question 5

SELECT 
	Description , 
	ISNULL(MaxQty,0.00) 
FROM 
	Sales.SpecialOffer;

--Question 6

SELECT 
	AVG(AverageRate) 
FROM  
	Sales.CurrencyRate
WHERE 
	FromCurrencyCode='USD' 
	AND 
	ToCurrencyCode='GBP' 
	AND 
	YEAR(CurrencyRateDate)=2005


--Question 7

SELECT 
	ROW_NUMBER() 
OVER(ORDER BY FirstName), 
	FirstName, 
	LastName 
FROM 
	Person.Person
WHERE 
	FirstName 
	LIKE 
	'%ss%'; 


--Question 8

SELECT 
	BusinessEntityID ,
	CommissionPct, 
	CommissionBand= 
	CASE 
		WHEN 
			CommissionPct = 0 then 'band 0'
		WHEN 
			CommissionPct > 0 and CommissionPct <= 0.01 then 'band 1'
		WHEN 
			CommissionPct > 0.01 and CommissionPct <= 0.015 then 'band 2'
		WHEN 
			CommissionPct > 0.015 then 'band 3'
	 END 
FROM 
	Sales.SalesPerson
ORDER BY 
	CommissionPct;

--Question 9

DECLARE 
	@Id int 
SELECT 
	@Id = BusinessEntityID 
FROM 
	Person.Person 
WHERE 
	PersonType='EM' 
	AND 
	FirstName='Ruth' 
	AND LastName='Ellerbrock'
EXEC 
	[dbo].[uspGetEmployeeManagers] @Id 

--Question 10

SELECT 
	ProductID, 
	Quantity 
FROM 
	Production.ProductInventory 
WHERE 
	Quantity = 
	(SELECT 
		MAX(dbo.ufnGetStock(ProductID)) 
	 FROM  
		Production.ProductInventory);
