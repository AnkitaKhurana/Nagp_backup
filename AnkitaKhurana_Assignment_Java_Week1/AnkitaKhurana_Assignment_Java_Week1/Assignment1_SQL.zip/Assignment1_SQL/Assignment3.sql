--Show the most recent five orders that were purchased from account numbers that have spent more than $70,000 with AdventureWorks.

use AdventureWorks;
SELECT 
TOP 5 
	* 
FROM 
	Sales.SalesOrderHeader 
WHERE 
	TotalDue>70000 
ORDER BY 
	SalesOrderHeader.TotalDue 
DESC; 