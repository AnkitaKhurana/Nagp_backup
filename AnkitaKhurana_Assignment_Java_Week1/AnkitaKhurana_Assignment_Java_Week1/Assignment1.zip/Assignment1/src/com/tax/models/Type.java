package com.tax.models;

public enum Type {
	RAW, MANUFACTURED, IMPORTED
}
